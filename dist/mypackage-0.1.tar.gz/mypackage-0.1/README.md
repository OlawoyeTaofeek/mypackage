# mypackage

This package was created by me as an example to explain how to publish your own python package.

# How to install